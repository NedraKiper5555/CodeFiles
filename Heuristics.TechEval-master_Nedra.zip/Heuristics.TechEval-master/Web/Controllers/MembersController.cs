﻿using System.Linq;
using System.Web.Mvc;
using Heuristics.TechEval.Core;
using Heuristics.TechEval.Web.Models;
using Heuristics.TechEval.Core.Models;
using Newtonsoft.Json;

namespace Heuristics.TechEval.Web.Controllers {

	public class MembersController : Controller {

		private readonly DataContext _context;

		public MembersController() {
			_context = new DataContext();
		}

		public ActionResult List() {
			var allMembers = _context.Members.ToList();

			return View(allMembers);
		}

		[HttpPost]
		public ActionResult New(NewMember data) {

            var newMember = new Member
            {
                Name = data.Name,
                Email = data.Email
            };
            if (ModelState.IsValid)
            {
                if (_context.Members.Count(m => m.Email.Equals(newMember.Email)) > 0)
                {
                    //Duplicate so don't insert
                    // to-do Send invalid message back to user interface
                }
                else
                {
                    _context.Members.Add(newMember);
                    _context.SaveChanges();
                }
            }
            return Json(JsonConvert.SerializeObject(newMember));
		}


        [HttpPost]
        public ActionResult UpdateMember(NewMember data)
        {

            var updateMember = new Member
            {
                Id = data.ID,
                Name = data.Name,
                Email = data.Email
            };
            if (ModelState.IsValid)
            {
                if (_context.Members.Count(m => m.Email.Equals(updateMember.Email) && m.Id != updateMember.Id) > 0)
                {
                    //Duplicate Email so don't change
                    // to-do Send invalid message back to user interface
                }
                else
                {
                _context.Members.Attach(updateMember);
                _context.Entry(updateMember).State = System.Data.Entity.EntityState.Modified;
                _context.SaveChanges(); 
                }                          
            }

            return RedirectToAction("List");
        }
    }
}